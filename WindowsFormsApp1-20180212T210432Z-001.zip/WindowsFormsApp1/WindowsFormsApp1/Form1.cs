﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public string Clicked = "";
        public Form1()
        {
            InitializeComponent();
            recycleBin.MouseClick += _clickTrigger;
            fileFolder.MouseClick += _clickTrigger;
            paintMS.MouseClick += _clickTrigger;
            startButton.MouseClick += _clickTrigger;
            startMenu.MouseClick += _clickTrigger;
            paintMS.MouseClick += _clickTrigger;
            _recycleBin("close");
            _fileFolder("close");
            _startButton("close");
            taskBar2.SendToBack();
            startButton.BringToFront();
        }

        private void _clickTrigger(object sender, EventArgs e)
        {
            Clicked = ((PictureBox)sender).Name;
            switch (Clicked)
            {
                case "recycleBin":
                    _recycleBin("open");
                    break;

                case "fileFolder":
                    _fileFolder("open");
                    break;

                case "startButton":
                    _startButton("open");
                    break;

                case "startMenu":
                    _startButton("close");
                    break;

            }
        }

        private void _recycleBin(string state)
        {
            if (state == "open")
            {
                recycleBinGUI.Visible = true;
                recycleBinX.Visible = true;
                recycleBinX.BringToFront();
            }
            if (state == "close")
            {
                recycleBinGUI.Visible = false;
                recycleBinX.Visible = false;
            }
        }
        private void _fileFolder(string state)
        {
            if (state == "open")
            {
                fileFolderGUI.Visible = true;
                fileFolderX.Visible = true;
                fileFolderX.BringToFront();
            }
            if (state == "close")
            {
                fileFolderGUI.Visible = false;
                fileFolderX.Visible = false;
            }
        }
        private void _startButton(string state)
        {
            if (state == "open")
            {
                startMenu.Visible = true;
            }
            if (state == "close")
            {
                startMenu.Visible = false;
            }
        }

        private void fileFolderX_Click(object sender, EventArgs e)
        {
            _fileFolder("close");
        }

        private void recycleBinX_Click(object sender, EventArgs e)
        {
            _recycleBin("close");
        }
    }
}
