﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.recycleBin = new System.Windows.Forms.PictureBox();
            this.fileFolder = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.startButton = new System.Windows.Forms.PictureBox();
            this.recycleBinGUI = new System.Windows.Forms.PictureBox();
            this.paintMS = new System.Windows.Forms.PictureBox();
            this.recycleBinX = new System.Windows.Forms.Button();
            this.fileFolderGUI = new System.Windows.Forms.PictureBox();
            this.fileFolderX = new System.Windows.Forms.Button();
            this.startMenu = new System.Windows.Forms.PictureBox();
            this.taskBar2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.recycleBin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileFolder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recycleBinGUI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paintMS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileFolderGUI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taskBar2)).BeginInit();
            this.SuspendLayout();
            // 
            // recycleBin
            // 
            this.recycleBin.BackColor = System.Drawing.Color.Transparent;
            this.recycleBin.Image = ((System.Drawing.Image)(resources.GetObject("recycleBin.Image")));
            this.recycleBin.Location = new System.Drawing.Point(12, 21);
            this.recycleBin.Name = "recycleBin";
            this.recycleBin.Size = new System.Drawing.Size(76, 80);
            this.recycleBin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.recycleBin.TabIndex = 0;
            this.recycleBin.TabStop = false;
            // 
            // fileFolder
            // 
            this.fileFolder.BackColor = System.Drawing.Color.Transparent;
            this.fileFolder.Image = ((System.Drawing.Image)(resources.GetObject("fileFolder.Image")));
            this.fileFolder.Location = new System.Drawing.Point(12, 122);
            this.fileFolder.Name = "fileFolder";
            this.fileFolder.Size = new System.Drawing.Size(77, 80);
            this.fileFolder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fileFolder.TabIndex = 1;
            this.fileFolder.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox3.Location = new System.Drawing.Point(32, 688);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 50);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.startButton.Image = ((System.Drawing.Image)(resources.GetObject("startButton.Image")));
            this.startButton.Location = new System.Drawing.Point(1, 570);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(88, 30);
            this.startButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.startButton.TabIndex = 3;
            this.startButton.TabStop = false;
            // 
            // recycleBinGUI
            // 
            this.recycleBinGUI.BackColor = System.Drawing.Color.Transparent;
            this.recycleBinGUI.Image = ((System.Drawing.Image)(resources.GetObject("recycleBinGUI.Image")));
            this.recycleBinGUI.Location = new System.Drawing.Point(314, 42);
            this.recycleBinGUI.Name = "recycleBinGUI";
            this.recycleBinGUI.Size = new System.Drawing.Size(407, 174);
            this.recycleBinGUI.TabIndex = 4;
            this.recycleBinGUI.TabStop = false;
            // 
            // paintMS
            // 
            this.paintMS.BackColor = System.Drawing.Color.Transparent;
            this.paintMS.Image = ((System.Drawing.Image)(resources.GetObject("paintMS.Image")));
            this.paintMS.Location = new System.Drawing.Point(13, 219);
            this.paintMS.Name = "paintMS";
            this.paintMS.Size = new System.Drawing.Size(79, 84);
            this.paintMS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.paintMS.TabIndex = 6;
            this.paintMS.TabStop = false;
            // 
            // recycleBinX
            // 
            this.recycleBinX.BackColor = System.Drawing.Color.Transparent;
            this.recycleBinX.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("recycleBinX.BackgroundImage")));
            this.recycleBinX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.recycleBinX.Location = new System.Drawing.Point(692, 42);
            this.recycleBinX.Name = "recycleBinX";
            this.recycleBinX.Size = new System.Drawing.Size(29, 27);
            this.recycleBinX.TabIndex = 7;
            this.recycleBinX.UseVisualStyleBackColor = false;
            this.recycleBinX.Click += new System.EventHandler(this.recycleBinX_Click);
            // 
            // fileFolderGUI
            // 
            this.fileFolderGUI.BackColor = System.Drawing.Color.Transparent;
            this.fileFolderGUI.Image = ((System.Drawing.Image)(resources.GetObject("fileFolderGUI.Image")));
            this.fileFolderGUI.Location = new System.Drawing.Point(358, 231);
            this.fileFolderGUI.Name = "fileFolderGUI";
            this.fileFolderGUI.Size = new System.Drawing.Size(394, 121);
            this.fileFolderGUI.TabIndex = 8;
            this.fileFolderGUI.TabStop = false;
            // 
            // fileFolderX
            // 
            this.fileFolderX.BackColor = System.Drawing.Color.Transparent;
            this.fileFolderX.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fileFolderX.BackgroundImage")));
            this.fileFolderX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.fileFolderX.ForeColor = System.Drawing.Color.Transparent;
            this.fileFolderX.Location = new System.Drawing.Point(723, 231);
            this.fileFolderX.Name = "fileFolderX";
            this.fileFolderX.Size = new System.Drawing.Size(29, 27);
            this.fileFolderX.TabIndex = 9;
            this.fileFolderX.UseVisualStyleBackColor = false;
            this.fileFolderX.Click += new System.EventHandler(this.fileFolderX_Click);
            // 
            // startMenu
            // 
            this.startMenu.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.startMenu.Image = ((System.Drawing.Image)(resources.GetObject("startMenu.Image")));
            this.startMenu.Location = new System.Drawing.Point(1, 184);
            this.startMenu.Name = "startMenu";
            this.startMenu.Size = new System.Drawing.Size(307, 416);
            this.startMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.startMenu.TabIndex = 10;
            this.startMenu.TabStop = false;
            // 
            // taskBar2
            // 
            this.taskBar2.BackColor = System.Drawing.Color.Transparent;
            this.taskBar2.Image = ((System.Drawing.Image)(resources.GetObject("taskBar2.Image")));
            this.taskBar2.Location = new System.Drawing.Point(-88, 402);
            this.taskBar2.Name = "taskBar2";
            this.taskBar2.Size = new System.Drawing.Size(1104, 198);
            this.taskBar2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.taskBar2.TabIndex = 12;
            this.taskBar2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1008, 601);
            this.Controls.Add(this.taskBar2);
            this.Controls.Add(this.startMenu);
            this.Controls.Add(this.fileFolderX);
            this.Controls.Add(this.fileFolderGUI);
            this.Controls.Add(this.recycleBinX);
            this.Controls.Add(this.paintMS);
            this.Controls.Add(this.recycleBinGUI);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.fileFolder);
            this.Controls.Add(this.recycleBin);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Broken Winows";
            ((System.ComponentModel.ISupportInitialize)(this.recycleBin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileFolder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recycleBinGUI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paintMS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileFolderGUI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taskBar2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox recycleBin;
        private System.Windows.Forms.PictureBox fileFolder;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox startButton;
        private System.Windows.Forms.PictureBox recycleBinGUI;
        private System.Windows.Forms.PictureBox paintMS;
        private System.Windows.Forms.Button recycleBinX;
        private System.Windows.Forms.PictureBox fileFolderGUI;
        private System.Windows.Forms.Button fileFolderX;
        private System.Windows.Forms.PictureBox startMenu;
        private System.Windows.Forms.PictureBox taskBar2;
    }
}

