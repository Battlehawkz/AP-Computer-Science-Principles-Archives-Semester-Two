﻿namespace WindowsFormsApp1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.GroupBox Colores;
        private System.Windows.Forms.Button Bisque;
        private System.Windows.Forms.Button RoyalBlue;
        private System.Windows.Forms.Button Aqua;
        private System.Windows.Forms.Button OrangeRed;
        private System.Windows.Forms.Button YellowGreen;
        private System.Windows.Forms.Button blanco;
        private System.Windows.Forms.Button LightSalmon;
        private System.Windows.Forms.Button Gray;
        private System.Windows.Forms.Button Maroon;
        private System.Windows.Forms.Button Pink;
        private System.Windows.Forms.Button Purple;
        private System.Windows.Forms.Button MediumSlateBlue;
        private System.Windows.Forms.Button Default1;
        private System.Windows.Forms.Button SteelBlue;
        private System.Windows.Forms.Button Yellow;
        private System.Windows.Forms.Button Green;
        private System.Windows.Forms.Button negro;
        private System.Windows.Forms.Button Gold;
        private System.Windows.Forms.Button DarkGray;
        private System.Windows.Forms.Button Brown;
        private System.Windows.Forms.Button Red;
        private System.Windows.Forms.PictureBox Pantalla;
        private System.Windows.Forms.GroupBox Figuras;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button Abrir;
        private System.Windows.Forms.Button Guardar;
        private System.Windows.Forms.Button Nuevo;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;

        /// <summary>
        /// Disposes resources used by the form.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// This method is required for Windows Forms designer support.
        /// Do not change the method contents inside the source code editor. The Forms designer might
        /// not be able to load this method if it was changed manually.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.Colores = new System.Windows.Forms.GroupBox();
            this.Bisque = new System.Windows.Forms.Button();
            this.RoyalBlue = new System.Windows.Forms.Button();
            this.Aqua = new System.Windows.Forms.Button();
            this.OrangeRed = new System.Windows.Forms.Button();
            this.YellowGreen = new System.Windows.Forms.Button();
            this.blanco = new System.Windows.Forms.Button();
            this.LightSalmon = new System.Windows.Forms.Button();
            this.Gray = new System.Windows.Forms.Button();
            this.Maroon = new System.Windows.Forms.Button();
            this.Pink = new System.Windows.Forms.Button();
            this.Purple = new System.Windows.Forms.Button();
            this.MediumSlateBlue = new System.Windows.Forms.Button();
            this.Default1 = new System.Windows.Forms.Button();
            this.SteelBlue = new System.Windows.Forms.Button();
            this.Yellow = new System.Windows.Forms.Button();
            this.Green = new System.Windows.Forms.Button();
            this.negro = new System.Windows.Forms.Button();
            this.Gold = new System.Windows.Forms.Button();
            this.DarkGray = new System.Windows.Forms.Button();
            this.Brown = new System.Windows.Forms.Button();
            this.Red = new System.Windows.Forms.Button();
            this.Figuras = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.Abrir = new System.Windows.Forms.Button();
            this.Guardar = new System.Windows.Forms.Button();
            this.Nuevo = new System.Windows.Forms.Button();
            this.Pantalla = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Colores.SuspendLayout();
            this.Figuras.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Colores
            // 
            this.Colores.BackColor = System.Drawing.Color.Transparent;
            this.Colores.Controls.Add(this.Bisque);
            this.Colores.Controls.Add(this.RoyalBlue);
            this.Colores.Controls.Add(this.Aqua);
            this.Colores.Controls.Add(this.OrangeRed);
            this.Colores.Controls.Add(this.YellowGreen);
            this.Colores.Controls.Add(this.blanco);
            this.Colores.Controls.Add(this.LightSalmon);
            this.Colores.Controls.Add(this.Gray);
            this.Colores.Controls.Add(this.Maroon);
            this.Colores.Controls.Add(this.Pink);
            this.Colores.Controls.Add(this.Purple);
            this.Colores.Controls.Add(this.MediumSlateBlue);
            this.Colores.Controls.Add(this.Default1);
            this.Colores.Controls.Add(this.SteelBlue);
            this.Colores.Controls.Add(this.Yellow);
            this.Colores.Controls.Add(this.Green);
            this.Colores.Controls.Add(this.negro);
            this.Colores.Controls.Add(this.Gold);
            this.Colores.Controls.Add(this.DarkGray);
            this.Colores.Controls.Add(this.Brown);
            this.Colores.Controls.Add(this.Red);
            this.Colores.Location = new System.Drawing.Point(7, 524);
            this.Colores.Name = "Colores";
            this.Colores.Size = new System.Drawing.Size(332, 76);
            this.Colores.TabIndex = 0;
            this.Colores.TabStop = false;
            // 
            // Bisque
            // 
            this.Bisque.BackColor = System.Drawing.Color.Bisque;
            this.Bisque.Location = new System.Drawing.Point(295, 48);
            this.Bisque.Margin = new System.Windows.Forms.Padding(1);
            this.Bisque.Name = "Bisque";
            this.Bisque.Size = new System.Drawing.Size(25, 25);
            this.Bisque.TabIndex = 20;
            this.Bisque.UseVisualStyleBackColor = false;
            this.Bisque.Click += new System.EventHandler(this.BisqueClick);
            // 
            // RoyalBlue
            // 
            this.RoyalBlue.BackColor = System.Drawing.Color.RoyalBlue;
            this.RoyalBlue.Location = new System.Drawing.Point(268, 48);
            this.RoyalBlue.Margin = new System.Windows.Forms.Padding(1);
            this.RoyalBlue.Name = "RoyalBlue";
            this.RoyalBlue.Size = new System.Drawing.Size(25, 25);
            this.RoyalBlue.TabIndex = 19;
            this.RoyalBlue.UseVisualStyleBackColor = false;
            this.RoyalBlue.Click += new System.EventHandler(this.RoyalBlueClick);
            // 
            // Aqua
            // 
            this.Aqua.BackColor = System.Drawing.Color.Cyan;
            this.Aqua.Location = new System.Drawing.Point(241, 48);
            this.Aqua.Margin = new System.Windows.Forms.Padding(1);
            this.Aqua.Name = "Aqua";
            this.Aqua.Size = new System.Drawing.Size(25, 25);
            this.Aqua.TabIndex = 18;
            this.Aqua.UseVisualStyleBackColor = false;
            this.Aqua.Click += new System.EventHandler(this.AquaClick);
            // 
            // OrangeRed
            // 
            this.OrangeRed.BackColor = System.Drawing.Color.Yellow;
            this.OrangeRed.Location = new System.Drawing.Point(160, 48);
            this.OrangeRed.Margin = new System.Windows.Forms.Padding(1);
            this.OrangeRed.Name = "OrangeRed";
            this.OrangeRed.Size = new System.Drawing.Size(25, 25);
            this.OrangeRed.TabIndex = 15;
            this.OrangeRed.UseVisualStyleBackColor = false;
            this.OrangeRed.Click += new System.EventHandler(this.OrangeRedClick);
            // 
            // YellowGreen
            // 
            this.YellowGreen.BackColor = System.Drawing.Color.YellowGreen;
            this.YellowGreen.Location = new System.Drawing.Point(214, 48);
            this.YellowGreen.Margin = new System.Windows.Forms.Padding(1);
            this.YellowGreen.Name = "YellowGreen";
            this.YellowGreen.Size = new System.Drawing.Size(25, 25);
            this.YellowGreen.TabIndex = 17;
            this.YellowGreen.UseVisualStyleBackColor = false;
            this.YellowGreen.Click += new System.EventHandler(this.YellowGreenClick);
            // 
            // blanco
            // 
            this.blanco.BackColor = System.Drawing.Color.White;
            this.blanco.Location = new System.Drawing.Point(52, 48);
            this.blanco.Margin = new System.Windows.Forms.Padding(1);
            this.blanco.Name = "blanco";
            this.blanco.Size = new System.Drawing.Size(25, 25);
            this.blanco.TabIndex = 11;
            this.blanco.UseVisualStyleBackColor = false;
            this.blanco.Click += new System.EventHandler(this.BlancoClick);
            // 
            // LightSalmon
            // 
            this.LightSalmon.BackColor = System.Drawing.Color.LightSalmon;
            this.LightSalmon.Location = new System.Drawing.Point(187, 48);
            this.LightSalmon.Margin = new System.Windows.Forms.Padding(1);
            this.LightSalmon.Name = "LightSalmon";
            this.LightSalmon.Size = new System.Drawing.Size(25, 25);
            this.LightSalmon.TabIndex = 16;
            this.LightSalmon.UseVisualStyleBackColor = false;
            this.LightSalmon.Click += new System.EventHandler(this.LightSalmonClick);
            // 
            // Gray
            // 
            this.Gray.BackColor = System.Drawing.Color.Gray;
            this.Gray.Location = new System.Drawing.Point(79, 48);
            this.Gray.Margin = new System.Windows.Forms.Padding(1);
            this.Gray.Name = "Gray";
            this.Gray.Size = new System.Drawing.Size(25, 25);
            this.Gray.TabIndex = 12;
            this.Gray.UseVisualStyleBackColor = false;
            this.Gray.Click += new System.EventHandler(this.GrayClick);
            // 
            // Maroon
            // 
            this.Maroon.BackColor = System.Drawing.Color.Maroon;
            this.Maroon.Location = new System.Drawing.Point(106, 48);
            this.Maroon.Margin = new System.Windows.Forms.Padding(1);
            this.Maroon.Name = "Maroon";
            this.Maroon.Size = new System.Drawing.Size(25, 25);
            this.Maroon.TabIndex = 13;
            this.Maroon.UseVisualStyleBackColor = false;
            this.Maroon.Click += new System.EventHandler(this.MaroonClick);
            // 
            // Pink
            // 
            this.Pink.BackColor = System.Drawing.Color.Pink;
            this.Pink.Location = new System.Drawing.Point(133, 48);
            this.Pink.Margin = new System.Windows.Forms.Padding(1);
            this.Pink.Name = "Pink";
            this.Pink.Size = new System.Drawing.Size(25, 25);
            this.Pink.TabIndex = 14;
            this.Pink.UseVisualStyleBackColor = false;
            this.Pink.Click += new System.EventHandler(this.PinkClick);
            // 
            // Purple
            // 
            this.Purple.BackColor = System.Drawing.Color.Purple;
            this.Purple.Location = new System.Drawing.Point(295, 20);
            this.Purple.Margin = new System.Windows.Forms.Padding(1);
            this.Purple.Name = "Purple";
            this.Purple.Size = new System.Drawing.Size(25, 25);
            this.Purple.TabIndex = 10;
            this.Purple.UseVisualStyleBackColor = false;
            this.Purple.Click += new System.EventHandler(this.PurpleClick);
            // 
            // MediumSlateBlue
            // 
            this.MediumSlateBlue.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.MediumSlateBlue.Location = new System.Drawing.Point(268, 20);
            this.MediumSlateBlue.Margin = new System.Windows.Forms.Padding(1);
            this.MediumSlateBlue.Name = "MediumSlateBlue";
            this.MediumSlateBlue.Size = new System.Drawing.Size(25, 25);
            this.MediumSlateBlue.TabIndex = 9;
            this.MediumSlateBlue.UseVisualStyleBackColor = false;
            this.MediumSlateBlue.Click += new System.EventHandler(this.MediumSlateBlueClick);
            // 
            // Default1
            // 
            this.Default1.BackColor = System.Drawing.Color.Black;
            this.Default1.Location = new System.Drawing.Point(6, 20);
            this.Default1.Name = "Default1";
            this.Default1.Size = new System.Drawing.Size(43, 53);
            this.Default1.TabIndex = 0;
            this.Default1.UseVisualStyleBackColor = false;
            this.Default1.Click += new System.EventHandler(this.Default1Click);
            // 
            // SteelBlue
            // 
            this.SteelBlue.BackColor = System.Drawing.Color.SteelBlue;
            this.SteelBlue.Location = new System.Drawing.Point(241, 20);
            this.SteelBlue.Margin = new System.Windows.Forms.Padding(1);
            this.SteelBlue.Name = "SteelBlue";
            this.SteelBlue.Size = new System.Drawing.Size(25, 25);
            this.SteelBlue.TabIndex = 8;
            this.SteelBlue.UseVisualStyleBackColor = false;
            this.SteelBlue.Click += new System.EventHandler(this.SteelBlueClick);
            // 
            // Yellow
            // 
            this.Yellow.BackColor = System.Drawing.Color.OrangeRed;
            this.Yellow.Location = new System.Drawing.Point(160, 20);
            this.Yellow.Margin = new System.Windows.Forms.Padding(1);
            this.Yellow.Name = "Yellow";
            this.Yellow.Size = new System.Drawing.Size(25, 25);
            this.Yellow.TabIndex = 5;
            this.Yellow.UseVisualStyleBackColor = false;
            this.Yellow.Click += new System.EventHandler(this.YellowClick);
            // 
            // Green
            // 
            this.Green.BackColor = System.Drawing.Color.Green;
            this.Green.Location = new System.Drawing.Point(214, 20);
            this.Green.Margin = new System.Windows.Forms.Padding(1);
            this.Green.Name = "Green";
            this.Green.Size = new System.Drawing.Size(25, 25);
            this.Green.TabIndex = 7;
            this.Green.UseVisualStyleBackColor = false;
            this.Green.Click += new System.EventHandler(this.GreenClick);
            // 
            // negro
            // 
            this.negro.BackColor = System.Drawing.Color.Black;
            this.negro.Location = new System.Drawing.Point(52, 20);
            this.negro.Margin = new System.Windows.Forms.Padding(1);
            this.negro.Name = "negro";
            this.negro.Size = new System.Drawing.Size(25, 25);
            this.negro.TabIndex = 1;
            this.negro.UseVisualStyleBackColor = false;
            this.negro.Click += new System.EventHandler(this.NegroClick);
            // 
            // Gold
            // 
            this.Gold.BackColor = System.Drawing.Color.Gold;
            this.Gold.Location = new System.Drawing.Point(187, 20);
            this.Gold.Margin = new System.Windows.Forms.Padding(1);
            this.Gold.Name = "Gold";
            this.Gold.Size = new System.Drawing.Size(25, 25);
            this.Gold.TabIndex = 6;
            this.Gold.UseVisualStyleBackColor = false;
            this.Gold.Click += new System.EventHandler(this.GoldClick);
            // 
            // DarkGray
            // 
            this.DarkGray.BackColor = System.Drawing.Color.DarkGray;
            this.DarkGray.Location = new System.Drawing.Point(79, 20);
            this.DarkGray.Margin = new System.Windows.Forms.Padding(1);
            this.DarkGray.Name = "DarkGray";
            this.DarkGray.Size = new System.Drawing.Size(25, 25);
            this.DarkGray.TabIndex = 2;
            this.DarkGray.UseVisualStyleBackColor = false;
            this.DarkGray.Click += new System.EventHandler(this.DarkGrayClick);
            // 
            // Brown
            // 
            this.Brown.BackColor = System.Drawing.Color.Brown;
            this.Brown.Location = new System.Drawing.Point(106, 20);
            this.Brown.Margin = new System.Windows.Forms.Padding(1);
            this.Brown.Name = "Brown";
            this.Brown.Size = new System.Drawing.Size(25, 25);
            this.Brown.TabIndex = 3;
            this.Brown.UseVisualStyleBackColor = false;
            this.Brown.Click += new System.EventHandler(this.BrownClick);
            // 
            // Red
            // 
            this.Red.BackColor = System.Drawing.Color.Red;
            this.Red.Location = new System.Drawing.Point(133, 20);
            this.Red.Margin = new System.Windows.Forms.Padding(1);
            this.Red.Name = "Red";
            this.Red.Size = new System.Drawing.Size(25, 25);
            this.Red.TabIndex = 4;
            this.Red.UseVisualStyleBackColor = false;
            this.Red.Click += new System.EventHandler(this.RedClick);
            // 
            // Figuras
            // 
            this.Figuras.Controls.Add(this.button3);
            this.Figuras.Controls.Add(this.button2);
            this.Figuras.Controls.Add(this.button1);
            this.Figuras.Location = new System.Drawing.Point(7, 445);
            this.Figuras.Name = "Figuras";
            this.Figuras.Size = new System.Drawing.Size(104, 73);
            this.Figuras.TabIndex = 2;
            this.Figuras.TabStop = false;
            this.Figuras.Text = "Shapes";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Location = new System.Drawing.Point(37, 35);
            this.button3.Margin = new System.Windows.Forms.Padding(1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(25, 25);
            this.button3.TabIndex = 9;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Button3Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Location = new System.Drawing.Point(73, 35);
            this.button2.Margin = new System.Windows.Forms.Padding(1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(25, 25);
            this.button2.TabIndex = 8;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Button2Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Location = new System.Drawing.Point(4, 35);
            this.button1.Margin = new System.Windows.Forms.Padding(1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(25, 25);
            this.button1.TabIndex = 7;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Button1Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button8);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Location = new System.Drawing.Point(7, 247);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(86, 83);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tools";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.Location = new System.Drawing.Point(44, 20);
            this.button8.Margin = new System.Windows.Forms.Padding(1);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(37, 39);
            this.button8.TabIndex = 12;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.Button8Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Location = new System.Drawing.Point(4, 20);
            this.button7.Margin = new System.Windows.Forms.Padding(1);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(38, 39);
            this.button7.TabIndex = 10;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.Button7Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Location = new System.Drawing.Point(4, 17);
            this.button4.Margin = new System.Windows.Forms.Padding(1);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(37, 39);
            this.button4.TabIndex = 13;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.Button4Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(7, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(133, 92);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cordinates";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(6, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Y:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(7, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "X:";
            this.label1.Click += new System.EventHandler(this.Label1Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Location = new System.Drawing.Point(7, 192);
            this.button5.Margin = new System.Windows.Forms.Padding(1);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(106, 39);
            this.button5.TabIndex = 13;
            this.button5.Text = "Clear";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Button5Click);
            // 
            // Abrir
            // 
            this.Abrir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Abrir.BackgroundImage")));
            this.Abrir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Abrir.Location = new System.Drawing.Point(12, 27);
            this.Abrir.Name = "Abrir";
            this.Abrir.Size = new System.Drawing.Size(40, 43);
            this.Abrir.TabIndex = 21;
            this.Abrir.UseVisualStyleBackColor = true;
            this.Abrir.Click += new System.EventHandler(this.AbrirClick);
            // 
            // Guardar
            // 
            this.Guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Guardar.BackgroundImage")));
            this.Guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Guardar.Location = new System.Drawing.Point(58, 27);
            this.Guardar.Name = "Guardar";
            this.Guardar.Size = new System.Drawing.Size(43, 43);
            this.Guardar.TabIndex = 22;
            this.Guardar.UseVisualStyleBackColor = true;
            this.Guardar.Click += new System.EventHandler(this.GuardarClick);
            // 
            // Nuevo
            // 
            this.Nuevo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Nuevo.BackgroundImage")));
            this.Nuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Nuevo.Location = new System.Drawing.Point(107, 27);
            this.Nuevo.Name = "Nuevo";
            this.Nuevo.Size = new System.Drawing.Size(37, 43);
            this.Nuevo.TabIndex = 23;
            this.Nuevo.UseVisualStyleBackColor = true;
            this.Nuevo.Click += new System.EventHandler(this.NuevoClick);
            // 
            // Pantalla
            // 
            this.Pantalla.BackColor = System.Drawing.Color.White;
            this.Pantalla.Location = new System.Drawing.Point(154, 27);
            this.Pantalla.Name = "Pantalla";
            this.Pantalla.Size = new System.Drawing.Size(842, 502);
            this.Pantalla.TabIndex = 24;
            this.Pantalla.TabStop = false;
            this.Pantalla.MouseClick += new System.Windows.Forms.MouseEventHandler(this.PantallaMouseClick);
            this.Pantalla.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PantallaMouseDown);
            this.Pantalla.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PantallaMouseMove);
            this.Pantalla.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PantallaMouseUp);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button11);
            this.groupBox3.Controls.Add(this.button10);
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Location = new System.Drawing.Point(7, 336);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(98, 93);
            this.groupBox3.TabIndex = 25;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Paintbrush";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Image = ((System.Drawing.Image)(resources.GetObject("button11.Image")));
            this.button11.Location = new System.Drawing.Point(43, 67);
            this.button11.Margin = new System.Windows.Forms.Padding(1);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(47, 18);
            this.button11.TabIndex = 29;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.Button11Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.Image = ((System.Drawing.Image)(resources.GetObject("button10.Image")));
            this.button10.Location = new System.Drawing.Point(43, 51);
            this.button10.Margin = new System.Windows.Forms.Padding(1);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(47, 15);
            this.button10.TabIndex = 28;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.Button10Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.Location = new System.Drawing.Point(43, 34);
            this.button9.Margin = new System.Windows.Forms.Padding(1);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(47, 15);
            this.button9.TabIndex = 27;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.Button9Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(43, 18);
            this.button6.Margin = new System.Windows.Forms.Padding(1);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(47, 15);
            this.button6.TabIndex = 26;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.Button6Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(17, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 15);
            this.label3.TabIndex = 26;
            this.label3.Text = "Open";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(63, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 16);
            this.label4.TabIndex = 27;
            this.label4.Text = "Save";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(109, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 16);
            this.label5.TabIndex = 28;
            this.label5.Text = "New";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(1008, 601);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.Pantalla);
            this.Controls.Add(this.Nuevo);
            this.Controls.Add(this.Guardar);
            this.Controls.Add(this.Abrir);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.Figuras);
            this.Controls.Add(this.Colores);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Untitled - Paint";
            this.Load += new System.EventHandler(this.MainFormLoad);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MainFormMouseUp);
            this.Colores.ResumeLayout(false);
            this.Figuras.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }
    }
}
